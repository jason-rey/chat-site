class Message():
    def __init__(self, _author, _contents):
        self.author = _author
        self.contents = _contents